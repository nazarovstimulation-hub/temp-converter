# Integrar esta plantilla en Invitalia.com

Incorpora esta plantilla de invitación de boda a mi proyecto existente de Invitalia.com. Examina primero su estructura y adapta el código a su framework y convenciones. Conserva el diseño en acuarela, los colores, la composición, las secciones y el español de España. No reemplaces el resto de la web.

## Archivos
- index.html: versión estática completa con CSS y JavaScript incluidos.
- assets/watercolor.png: ilustración original de la portada.
- No requiere npm ni compilación. Para visualizarla, abre index.html con la carpeta assets al lado.
- Las tipografías se solicitan a Google Fonts; sin conexión se usan fuentes de reserva.

## Funciones actuales
- Diseño adaptable a móvil y escritorio.
- Personalización de dos nombres y fecha mediante un diálogo.
- Cuenta atrás hasta las 17:00 de la fecha elegida, en la zona horaria del navegador.
- Historia, programa, ubicación pendiente, paleta de vestimenta y preguntas frecuentes.
- Formulario de asistencia de demostración. Solo guarda una respuesta en localStorage del navegador; no envía nada ni dispone de base de datos.
- Los nombres, fechas, horarios e historia son ejemplos.

## Integración solicitada
1. Crea una plantilla reutilizable llamada «Intercambio de anillos».
2. Haz editables nombres, fecha, hora, zona horaria, historia, programa, ubicación, colores, preguntas y textos desde el editor existente.
3. Sustituye localStorage por el mecanismo de persistencia existente del proyecto. Separa las respuestas por invitación y huésped.
4. Conecta RSVP a la API real y muestra confirmación solo cuando el servidor acepte la respuesta. Aplica validación y protección contra abuso. No afirmes que se ha enviado si no existe conexión real.
5. Añade la dirección y el enlace a mapas cuando la pareja configure una ubicación válida.
6. Mantén INVITALIA y el lema de marca Smart invitations. Todo el resto de la interfaz debe permanecer en español.
7. No añadas pagos, música ni servicios externos nuevos sin que se pidan. Esta versión tiene portada estática, no vídeo.
8. Comprueba móvil, accesibilidad del diálogo, formulario, enlaces y cuenta atrás. Conserva los datos y funciones existentes.

El dominio Invitalia.com no está conectado por este paquete. La versión desplegada de demostración y el repositorio de alojamiento son independientes de tu proyecto de Claude.
