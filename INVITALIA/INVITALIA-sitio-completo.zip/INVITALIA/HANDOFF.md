# INVITALIA.co — estado del proyecto (25-10-2026)

Sitio en producción: https://invitalia.co (Cloudflare Workers + D1, plan gratuito). Dirección temporal: https://invitalia.nazarovstimulation.workers.dev
Repositorio: github.com/nazarovstimulation-hub/temp-converter, carpeta `INVITALIA/`, rama `claude/invitalia-logo-concepts-jukw3p`.
Cada `git push` a esa rama redespliega el sitio con GitHub Actions (`github-workflows/cloudflare.yml`).

## Qué contiene
- `site/` sitio estático: `index.html` (landing con galería de 34 plantillas), `editor.html` (editor con vista previa, guardado en la nube, publicación y pago), `guest.html` (página pública de la invitación, servida en `/i/:slug`), `404.html`.
- `site/assets/invitation.js` + `invitation.css`: renderizado de la invitación (diseño «Intercambio de anillos»: portada con nombres en caligrafía, cuenta atrás, nuestra historia, programa, lugar y paleta de colores, preguntas frecuentes, RSVP, pie). 13 temas de color (`.t-*`).
- `site/assets/templates.js`: catálogo de las 34 plantillas (id, nombre, categoría, tema, foto). `site/assets/covers/`: fotos 01–34 (1024×1536) y miniaturas `-mini` (320×480).
- `site/assets/i18n.js`: textos en es (principal), en, it, pt, fr, de, ru. `scripts/build-templates.mjs` regenera galería, muestras del editor, textos de plantillas y listas del servidor.
- `cloudflare/`: Worker (API + sitio + D1), `wrangler.toml`, migración SQL, pruebas. `server/`: misma API en Node.js para ejecutar en local (`npm start`), pruebas y herramientas de diagnóstico.
- `logos/`: 10 conceptos de logotipo. `README.md` y `DEPLOY.md`: instrucciones completas.

## API (idéntica en Worker y Node)
`GET /api/health` · `POST /api/invitations` → {id, editToken} · `GET/PUT /api/invitations/:id` (Bearer editToken) · `GET …/responses`, `GET …/responses.csv` · `POST …/checkout`, `POST …/checkout/verify` · `POST /api/stripe/webhook` · `GET /api/i/:slug` · `POST /api/i/:slug/rsvp`.

## Pendiente
- Stripe: añadir los secretos `STRIPE_SECRET_KEY` y `STRIPE_WEBHOOK_SECRET` en GitHub (Settings → Secrets) y relanzar el deploy; hasta entonces los pagos están en modo de prueba (publica al instante). Webhook: `https://invitalia.co/api/stripe/webhook`, eventos `checkout.session.completed` y `checkout.session.async_payment_succeeded`.
- No hay registro de usuarios ni panel con login: el acceso a cada invitación es por enlace con token de edición.
